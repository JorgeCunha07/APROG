import java.util.Scanner;

public class F {
    static Scanner read =new Scanner  (System.in);
    public static void main(String[] args) {
        int[] juros = new int [6];
    }

    public static void fill (int[]juros){
        int num;
        for(int i=0;i <juros.length; i++){

        }
    }
}
