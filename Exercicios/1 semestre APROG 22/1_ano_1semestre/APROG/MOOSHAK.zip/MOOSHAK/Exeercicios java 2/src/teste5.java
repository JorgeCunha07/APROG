public class teste5 {
    public static void main(String[] args) {

    }
    public static int intervalo (int num1,int num2){
        int min, max;
        max= (Math.max(num1,num2));
        min = (Math.min(num1,num2));

    return max;
    }
}
